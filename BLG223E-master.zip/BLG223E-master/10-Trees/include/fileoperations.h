#pragma once

#include "phone_tree.h"

void read_fromfile(Phone_Tree&, const char*);
void write_tofile(Phone_Tree&, const char*);