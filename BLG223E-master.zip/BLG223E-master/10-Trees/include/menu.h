#pragma once
#include "phone_tree.h"

void print_menu();
bool perform_operation(char, Phone_Tree&);