#include <stdlib.h>
#include <iostream>
#include "examples.h"

using namespace std;

// unordered-set/map, utility->pair
int main()
{

	//vector_example();
	//stack_example();
	//queue_example();
	//pqueue_example();
	//map_example();
	//iterator_example();
	//list_example();
	//set_example();
	//unordered_set_map_example();
	//wfreq_example();

	getchar();
	return EXIT_SUCCESS; //-->stdlib.h
}
