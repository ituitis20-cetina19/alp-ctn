#pragma once
#include "fileoperations.h"

void add_record(PhonebookFile&);
void search_record(PhonebookFile&);
void update_record(PhonebookFile&);
void delete_record(PhonebookFile&);