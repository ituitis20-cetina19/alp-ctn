#pragma once
#include "fileoperations.h"

void print_menu();
bool perform_operation(char,PhonebookFile&);