struct Node{
	char character;
	Node * next;	
};
