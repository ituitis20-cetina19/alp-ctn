#define RIGHT   1
#define LEFT    2
#define UP      3
#define DOWN    4

#define MAZE_HOR_SIZE    8
#define MAZE_VER_SIZE    8
#define WALL   '#'
#define PATH   ' '
#define GONE   'o'