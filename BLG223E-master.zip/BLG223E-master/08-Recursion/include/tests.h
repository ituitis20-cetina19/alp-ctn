#pragma once

void test_factorial(int);
void test_binary_sum(int);
void test_permutations(int);
void test_n_queens(int);
void test_hanoi(int);
void test_recursive_maze();
