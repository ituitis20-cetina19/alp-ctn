#include <iostream>
#include <stdlib.h>

#include "tests.h"

using namespace std;

int main()
{
	
	//test_factorial(3);
	//test_binary_sum(10);
	//test_permutations(3);
	//test_n_queens(8);
	//test_hanoi(3);
	test_recursive_maze();

	getchar();
	return EXIT_SUCCESS; 
}




