#pragma once

struct Phone_Record{
	char* name;	
	char* phonenum;
};