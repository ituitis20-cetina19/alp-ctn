#pragma once
#include "phone_list.h"

void print_menu();
bool perform_operation(char, Phone_List&);