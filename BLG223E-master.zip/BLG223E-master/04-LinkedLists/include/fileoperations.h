#pragma once

#include "phone_list.h"

void read_fromfile(Phone_List&, const char*);
void write_tofile(Phone_List&, const char*);