#pragma once

void test_traversals();
void test_bst();
