#pragma once

#include "number_list.h"

struct Phone_Record{
	char* name;
	Number_List* numbers;
};