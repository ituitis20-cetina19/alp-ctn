#pragma once

struct Number_Record
{
    int area_code;
    int num;
};